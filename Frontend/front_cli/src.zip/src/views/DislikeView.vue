<template>
  <div>
    <memberDislike />
    <memberAllergy />
  </div>

</template>

<script setup>
  import memberDislike from '@/components/dislikePage/memberDislike.vue'
  import memberAllergy from '@/components/dislikePage/memberAllergy.vue'
</script>

<style>
/* 추가적인 스타일 */
</style>
